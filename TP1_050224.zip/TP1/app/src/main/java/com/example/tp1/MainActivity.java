package com.example.tp1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    protected Button BtnValidate;
    protected TextInputEditText pseudoInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BtnValidate = findViewById(R.id.Btn_Validate);
        BtnValidate.setEnabled(false);
        pseudoInput = findViewById(R.id.PseudTxtInput);
        pseudoInput.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if ( count > 3)
                            BtnValidate.setEnabled(true);
                        else
                            BtnValidate.setEnabled(false);
                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                }
        );
    }

}